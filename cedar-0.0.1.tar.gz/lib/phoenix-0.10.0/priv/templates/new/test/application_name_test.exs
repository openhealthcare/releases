defmodule <%= application_module %>Test do
  use ExUnit.Case

  test "the truth" do
    assert 1 + 1 == 2
  end
end
